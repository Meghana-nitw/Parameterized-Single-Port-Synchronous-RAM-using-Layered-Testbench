class scoreboard;

    mailbox #(transaction) mon2scb;

    bit [7:0] model_mem [16];
    bit valid [16];

    function new(mailbox #(transaction) m);
        mon2scb = m;

        foreach(model_mem[i]) begin
            model_mem[i] = 0;
            valid[i] = 0;
        end
    endfunction

    task run();

        transaction t;

        forever begin

            mon2scb.get(t);

            if(t.we) begin

                model_mem[t.addr] = t.wdata;
                valid[t.addr] = 1;

                $display("WRITE PASS addr=%0h data=%0h", t.addr, t.wdata);

            end
            else begin

                if(valid[t.addr]) begin

                    if(t.rdata == model_mem[t.addr])
                        $display("READ PASS addr=%0h data=%0h", t.addr, t.rdata);

                    else
                        $display("READ FAIL addr=%0h expected=%0h got=%0h",
                                 t.addr, model_mem[t.addr], t.rdata);

                end

            end

        end

    endtask

endclass
