class driver;

virtual ram_if vif;
mailbox #(transaction) gen2drv;

function new(virtual ram_if vif,
             mailbox #(transaction) m);

this.vif = vif;
gen2drv = m;

endfunction

task run();

transaction t;

forever begin

gen2drv.get(t);

@(vif.drv_cb);

vif.drv_cb.we <= t.we;
vif.drv_cb.addr <= t.addr;
vif.drv_cb.wdata <= t.wdata;

@(vif.drv_cb);
vif.drv_cb.we <= 0;

end

endtask

endclass
