module ram #(
    parameter DATA_WIDTH = 8,
    parameter ADDR_WIDTH = 4,
    parameter DEPTH = 16
)(
    input logic clk,
    input logic rst,
    input logic we,
    input logic [ADDR_WIDTH-1:0] addr,
    input logic [DATA_WIDTH-1:0] wdata,
    output logic [DATA_WIDTH-1:0] rdata
);

logic [DATA_WIDTH-1:0] mem [0:DEPTH-1];

integer i;

always_ff @(posedge clk) begin

    if (rst) begin

        rdata <= 0;

        // Initialize entire memory
        for (i = 0; i < DEPTH; i = i + 1) begin
            mem[i] <= 0;
        end

    end
    else begin

        if (we) begin
            mem[addr] <= wdata;
            rdata <= wdata; // write-first behaviour
        end
        else begin
            rdata <= mem[addr];
        end

    end

end

endmodule
