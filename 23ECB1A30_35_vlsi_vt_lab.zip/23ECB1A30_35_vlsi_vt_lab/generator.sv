class generator;

    mailbox #(transaction) gen2drv;

    int count; // number of transactions to generate

    function new(mailbox #(transaction) m);
        gen2drv = m;
    endfunction


    task run();

        transaction t;

        repeat(count) begin

            t = new();

            if(!t.randomize())
                $fatal(1,"Randomization failed");

            gen2drv.put(t);

        end

    endtask

endclass
