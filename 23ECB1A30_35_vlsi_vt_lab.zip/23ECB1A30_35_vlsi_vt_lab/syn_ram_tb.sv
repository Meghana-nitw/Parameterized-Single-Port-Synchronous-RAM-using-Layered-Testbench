module tb;

    bit clk;

    // Clock generation
    always #5 clk = ~clk;

    // Interface instance
    ram_if #(8,4) intf(clk);

    // DUT instance
    ram #(8,16) DUT (
        .clk (clk),
        .rst (intf.rst),
        .we (intf.we),
        .addr (intf.addr),
        .wdata (intf.wdata),
        .rdata (intf.rdata)
    );

    // Environment handle
    environment env;

    initial begin
        // Initialize clock
        clk = 0;

        // Apply reset
        intf.rst = 1;
        intf.we = 0;
        intf.addr = 0;
        intf.wdata = 0;

        #10;
        intf.rst = 0;

        // Create environment
        env = new(intf);

        // Number of transactions
        env.gen.count = 100;

        // Start verification environment
        env.run();

        // Simulation run time
        #1000;

        $display("Simulation Finished");
        $finish;
    end

endmodule
