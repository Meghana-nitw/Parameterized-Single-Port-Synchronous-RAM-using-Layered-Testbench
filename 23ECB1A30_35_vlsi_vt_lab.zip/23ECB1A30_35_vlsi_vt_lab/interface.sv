interface ram_if #(parameter DATA_WIDTH=8, ADDR_WIDTH=4)(input logic clk);

logic rst;
logic we;
logic [ADDR_WIDTH-1:0] addr;
logic [DATA_WIDTH-1:0] wdata;
logic [DATA_WIDTH-1:0] rdata;

clocking drv_cb @(posedge clk);
    default input #1 output #1;
    output rst, we, addr, wdata;
    input rdata;
endclocking

clocking mon_cb @(posedge clk);
    default input #1 output #1;
    input rst, we, addr, wdata, rdata;
endclocking

endinterface
