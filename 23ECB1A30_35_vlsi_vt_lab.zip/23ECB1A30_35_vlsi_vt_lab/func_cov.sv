class coverage;

transaction t;

covergroup cg;

coverpoint t.we {
bins read = {0};
bins write = {1};
}

coverpoint t.addr {
bins low = {[0:3]};
bins mid = {[4:11]};
bins high = {[12:15]};
}

cross t.we, t.addr;

endgroup

function new();
cg = new();
endfunction

function void sample(transaction tx);

t = tx;
cg.sample();

endfunction

endclass
