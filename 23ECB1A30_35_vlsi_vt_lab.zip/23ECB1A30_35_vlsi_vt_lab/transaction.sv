class transaction;

    rand bit we;
    rand bit [3:0] addr;
    rand bit [7:0] wdata;

    bit [7:0] rdata;

    // generate both reads and writes
    constraint we_c {
        we dist {1 := 50, 0 := 50};
    }

endclass
