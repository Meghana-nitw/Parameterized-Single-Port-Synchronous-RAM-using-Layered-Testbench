class monitor;

    virtual ram_if vif;
    mailbox #(transaction) mon2scb;

    function new(virtual ram_if vif,
                 mailbox #(transaction) m);
        this.vif = vif;
        this.mon2scb = m;
    endfunction

    task run();

        transaction t;

        forever begin

            @(vif.mon_cb);

            t = new();

            // Direct sampling (NO manual delay handling)
            t.we = vif.mon_cb.we;
            t.addr = vif.mon_cb.addr;
            t.wdata = vif.mon_cb.wdata;
            t.rdata = vif.mon_cb.rdata;

            mon2scb.put(t);

        end

    endtask

endclass
